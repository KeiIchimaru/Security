﻿from bottle import get, post, route, request, run, template, static_file, install
from bottle_sqlite import SQLitePlugin
import os

DB_NAME = 'test.db'
install(SQLitePlugin(dbfile=DB_NAME))

@route('/static/<file_path:path>')
def staticFile(file_path):
    return static_file(file_path, root='./static/')

# ###################################################################################
@get('/login')
def loginGet():
    return template("login", message="")

@post('/login')
def loginPost(db):
    id = request.forms.get('id')
    password = request.forms.get('password')
    sql = f"SELECT * FROM employee WHERE id={id} AND password='{password}'"
    cur = db.execute(sql)
    # sql = "SELECT * FROM employee WHERE id=:id AND password=':password'"
    # params = { "id": id, "password": password }
    # cur = db.execute(sql, params)
    row = cur.fetchone()
    if row is None:
        message = "ユーザIDまたはパスワードに誤りがあります。"
        return template("login", message=message)
    name = row[1]
    mail = row[2]
    return template("loginOK.html", name=name, mail=mail)

# ###################################################################################
@get('/search')
def searchGet():
    return template("search", message=None, rows=None)

@post('/search')
def searchPost(db):
    id = request.forms.get('id')
    sql = f"SELECT id,name,mail FROM employee WHERE id={id}"
    print(sql)
    cur = db.execute(sql)
    rows = cur.fetchall() # cur.fetchone()
    message = None
    if rows is None:
        message = "ユーザ"
    return template("search", message=message, rows=rows)

# ###################################################################################
@get('/xss')
def xssGet():
    return template("xss", message=None, name=None)

@post('/xss')
def xssPost(db):
    name = request.forms.getunicode('name')
    html = "<h1>クロスサイトスクリプティング</h1><br/><br/>"
    html += name
    html += "さんの登録を行いました。"
    return html
    # return template("xss", message=None, name=name)
# ###################################################################################
DIR_PATH = "views"
@get('/cat')
def catGet():
    files = [
        f for f in os.listdir(DIR_PATH) if os.path.isfile(os.path.join(DIR_PATH, f))
    ]
    return template("cat", message=None, files=files)

@post('/cat')
def catPost(db):
    name = request.forms.getunicode('fileName')
    path = os.path.join(DIR_PATH, name)
    data = []
    with open(path, 'r', encoding='UTF-8') as f:
        data = f.readlines()
    return template("cat2", message=None, name=name, data=data)


# ###################################################################################

run(host='localhost', port=8080)
